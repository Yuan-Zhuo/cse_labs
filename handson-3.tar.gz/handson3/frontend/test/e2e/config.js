(function (){
  'use strict';

  casper.options.viewportSize = {
    width: 1024,
    height: 768
  };
}());
